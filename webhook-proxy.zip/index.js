﻿// index.js - Webhook receiver PROXY para EasyPanel
const express = require('express');
const axios = require('axios');

const PORT = process.env.PORT || 3002;
const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:3001';

const app = express();
app.use(express.json());

app.post('/api/webhooks/evolution/:instanceId', async (req, res) => {
  try {
    const { instanceId } = req.params;
    const webhookData = req.body;
    
    console.log('PROXY: Webhook recebido para', instanceId);
    console.log('PROXY: Evento:', webhookData.event);

    try {
      const response = await axios.post(
        BACKEND_URL + '/api/webhooks/evolution/' + instanceId,
        webhookData,
        { headers: { 'Content-Type': 'application/json' }, timeout: 30000 }
      );
      
      console.log('PROXY: Webhook encaminhado com sucesso:', response.status);
      res.json({ success: true, proxied: true });
      
    } catch (proxyError) {
      console.error('PROXY: Erro ao encaminhar:', proxyError.message);
      res.json({ success: true, proxied: false, error: proxyError.message });
    }
    
  } catch (error) {
    console.error('PROXY: Erro geral:', error.message);
    res.json({ success: true, error: error.message });
  }
});

app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'webhook-proxy', backendUrl: BACKEND_URL });
});

app.get('/', (req, res) => {
  res.json({ message: 'WhatsAI Webhook Proxy', backendUrl: BACKEND_URL });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log('Webhook Proxy rodando na porta', PORT);
  console.log('Encaminhando webhooks para:', BACKEND_URL);
});
